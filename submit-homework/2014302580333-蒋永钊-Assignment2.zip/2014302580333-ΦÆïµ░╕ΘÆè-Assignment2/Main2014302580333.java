package DealTeacher;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  


public class Main2014302580333 {
	public static boolean isEmail(String email){     
	     String str="^([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)*@([a-zA-Z0-9]*[-_]?[a-zA-Z0-9]+)+[\\.][A-Za-z]{2,3}([\\.][A-Za-z]{2})?$";
	     Pattern pat = Pattern.compile(str);     
	     Matcher mat = pat.matcher(email);         
	     return mat.matches();     
	     } 
	 
	public static void main(String args[] ) throws IOException{
		
		// 爬取老师页面
		String urlhtml = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Peng%20Tian%20You";
		String htmlPath = "Teacher.html";
		//写入老师信息
		HttpRequest requesthtml = HttpRequest.get(urlhtml);
		requesthtml.receive(new File(htmlPath));

		/*将老师的信息写入txt
		 * 
		 */
		Document doc = Jsoup.parse (new File("./Teacher.html"), "utf-8","");
		String name=doc.select("h3").text();//获得老师姓名
		String rest=doc.select("p").text();//获得老师其他信息
		String [] str=rest.split(" ");
		
		
		
		FileWriter fileWriter=new FileWriter("./Teacher.txt");
		
		//写入信息
		fileWriter.write(name+"\n");
		System.out.println(isEmail(str[8]));  //验证邮箱
		if (isEmail(str[8])){
			for (int i=0;i<str.length;i++){
				fileWriter.write(str[i]+"\n");
			}
		}
		
		fileWriter.flush();
		fileWriter.close();
		
	}

}
